#Hussain Ghazali
#K173900
#IR Assignment 3
  
# !** importing library and packages **!

import re
import os
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from textblob import Word
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, confusion_matrix
from sklearn.ensemble import RandomForestClassifier
import pandas
import math
import xlrd
import PySimpleGUI as sg
import tkinter as tk

# !** Dataset folder into CSV file **!

data_folder = r'G:\bbcsport'
folders = ["athletics","cricket","football","rugby","tennis"]

os.chdir(data_folder)

x = []
y = []

for i in folders:
    files = os.listdir(i)
    for text_file in files:
        file_path = i + "/" +text_file
        print("reading file:", file_path)
        with open(file_path) as f:
            data = f.readlines()
        data = ' '.join(data)
        x.append(data)
        y.append(i)
        
# !** Classify into 2 parts NEWS(x) AND TYPE(y)  **!        
   
data = {'news': x, 'type': y}       
df = pd.DataFrame(data)
print('writing csv flie ...')
df.to_csv(r'G:\bbcsport\dataset.csv', index=False)

# !** Process of Cleaning from the CSV file **!

def clean_str(string):

    string = re.sub(r"\'s", "", string)
    string = re.sub(r"\'ve", "", string)
    string = re.sub(r"n\'t", "", string)
    string = re.sub(r"\'re", "", string)
    string = re.sub(r"\'d", "", string)
    string = re.sub(r"\'ll", "", string)
    string = re.sub(r",", "", string)
    string = re.sub(r"!", " ! ", string)
    string = re.sub(r"\(", "", string)
    string = re.sub(r"\)", "", string)
    string = re.sub(r"\?", "", string)
    string = re.sub(r"'", "", string)
    string = re.sub(r"[^A-Za-z0-9(),!?\'\`]", " ", string)
    string = re.sub(r"[0-9]\w+|[0-9]","", string)
    string = re.sub(r"\s{2,}", " ", string)
    return string.strip().lower()

data = pd.read_csv( r'G:\bbcsport\dataset.csv')
x = data['news'].tolist()
y = data['type'].tolist()

# !** Lemitization and Stemming and Processing Data **!

for index,value in enumerate(x):
    print("processing data:",index)
    x[index] = ' '.join([Word(word).lemmatize() for word in clean_str(value).split()])

vect = TfidfVectorizer(stop_words='english',min_df=30)
X = vect.fit_transform(x)
Y = np.array(y)

# !** Solving Eucleadian Distance **!

x = pandas.read_excel(r'G:\bbcsport\KnnDatasetX.xlsx')
y = pandas.read_excel(r'G:\bbcsport\KnnDatasetY.xlsx')
distance = math.sqrt(sum([(a - b) ** 2 for a, b in zip(x, y)]))
model = RandomForestClassifier(n_estimators=300, max_depth=150,n_jobs=1)
bookX = xlrd.open_workbook(r'G:\bbcsport\KnnDatasetX.xlsx')
bookY = xlrd.open_workbook(r'G:\bbcsport\KnnDatasetY.xlsx')
sheetX = bookX.sheet_by_name('Sheet1')
sheetY = bookY.sheet_by_name('Sheet1')
dataX = [[sheetX.cell_value(r, c) for c in range(sheetX.ncols)] for r in range(sheetX.nrows)]
dataY = [[sheetY.cell_value(r, c) for c in range(sheetY.ncols)] for r in range(sheetY.nrows)]
print(dataX)
print(dataY)

# !** Extracting Features **!

print("no of features extracted:",X.shape[1])

X_train, X_test, y_train, y_test = train_test_split(X, Y, test_size=0.20, random_state=42)

# !** Test and Train Data shape **!

print("train size:", X_train.shape)
print("test size:", X_test.shape)

model.fit(X_train, y_train)

# !** Model Prediction **!

y_pred = model.predict(X_test)
c_mat = confusion_matrix(y_test,y_pred)
acc = accuracy_score(y_test,y_pred)
sg.Popup('Euclidean distance file Constructed', 'Confusion Matrix and Accuracy Processed')
root = tk.Tk()
a = tk.Label(root, text="Confusion Matrix:")
b = tk.Label(root, text=c_mat)
c = tk.Label(root, text="Accuracy:")
d = tk.Label(root, text=acc*100)
a.pack()
b.pack()
c.pack()
d.pack()
root.mainloop()
print("Confusion Matrix:\n", c_mat)
print("Euclidean distance from x to y: ",distance)
print("\nAccuracy: ",acc*100)


